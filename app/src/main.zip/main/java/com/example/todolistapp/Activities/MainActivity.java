package com.example.todolistapp;


import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.todolistapp.Adapters.TaskAdapter;
import com.example.todolistapp.Model.Task;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText taskNameInput, taskTimeInput, taskDescriptionInput;
    private Switch markAsCompleteSwitch;
    private ListView taskListView;
    private ArrayList<Task> taskList;
    private TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskNameInput = findViewById(R.id.taskNameInput);
        taskTimeInput = findViewById(R.id.taskTimeInput);
        taskDescriptionInput = findViewById(R.id.taskDescriptionInput);
        markAsCompleteSwitch = findViewById(R.id.markAsCompleteSwitch);
        Button addButton = findViewById(R.id.addButton);
        Button showListButton = findViewById(R.id.showListButton);
        taskListView = findViewById(R.id.taskListView);

        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(this, taskList);
        taskListView.setAdapter(taskAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = taskNameInput.getText().toString();
                String time = taskTimeInput.getText().toString();
                String description = taskDescriptionInput.getText().toString();
                boolean isComplete = markAsCompleteSwitch.isChecked();

                if (!name.isEmpty() && !time.isEmpty() && !description.isEmpty()) {
                    Task task = new Task(name, time, description, isComplete);
                    taskList.add(task);
                    taskAdapter.notifyDataSetChanged();

                    taskNameInput.setText("");
                    taskTimeInput.setText("");
                    taskDescriptionInput.setText("");
                    markAsCompleteSwitch.setChecked(false);
                } else {
                    Toast.makeText(MainActivity.this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        showListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskAdapter.notifyDataSetChanged();
            }
        });
    }
}