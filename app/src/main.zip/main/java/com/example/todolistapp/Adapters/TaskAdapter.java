package com.example.todolistapp.Adapters;


import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;

import com.example.todolistapp.Model.Task;
import com.example.todolistapp.R;

import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<Task> {

    public TaskAdapter(@NonNull Context context, ArrayList<Task> tasks) {
        super(context, 0, tasks);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Task task = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.task_row, parent, false);
        }

        TextView taskName = convertView.findViewById(R.id.taskName);
        TextView taskTime = convertView.findViewById(R.id.taskTime);
        TextView taskDescription = convertView.findViewById(R.id.taskDescription);
        Button editButton = convertView.findViewById(R.id.editButton);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        taskName.setText(task.getName());
        taskTime.setText(task.getTime());
        taskDescription.setText(task.getDescription());

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog(task);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                remove(task);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    private void showEditDialog(Task task) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Edit Task");

        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_task, null);
        EditText editName = view.findViewById(R.id.editTaskName);
        EditText editTime = view.findViewById(R.id.editTaskTime);
        EditText editDescription = view.findViewById(R.id.editTaskDescription);

        editName.setText(task.getName());
        editTime.setText(task.getTime());
        editDescription.setText(task.getDescription());

        builder.setView(view)
                .setPositiveButton("Save", (dialog, which) -> {
                    task.setName(editName.getText().toString());
                    task.setTime(editTime.getText().toString());
                    task.setDescription(editDescription.getText().toString());
                    notifyDataSetChanged();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}